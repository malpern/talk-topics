# Waka Python Classroom

An authored, local 81 × 55 arena for twelve Python agents. Python 3.9+;
standard library only. The native Settings UI requires macOS 15+.

Open Waka → File → Settings → Python Agent Classroom Mode. Start the default
roster, save the starter kit, edit `starter_agent.py`, and load it into a slot.
Source changes load on the next round. See `guide/index.html` in the downloaded
kit, or `Documentation/site/classroom/index.html` in the repository.

Write `decide(observation, memory)` and return `up`, `right`, `down`, `left`,
`stay`, or `{"move": "up", "signal": "hello"}`. Signals are at most 48
characters. Memory is private and persists within a round. The host supplies
the optional `waka` helpers. Each agent runs independently with a common
deadline; three invalid decisions or one timeout stop that agent.

The structured classroom API is separate from the arcade's image-only API.
These classroom rules and graphics are original, not ROM-derived.

## Headless experiment

From this directory (macOS or another POSIX host):

```sh
python3 runner.py --config sample-config.json --headless --result result.json
```

Config fields: `seed` (integer), `ticks` (1–4800), `budget_ms` (20–500),
`vaults`, `portals`, `bounty`, `storms` (booleans), and `agents` (2–12 objects).
An agent object has a `name` and either a `style` or a `.py` file `path`.
Styles: forager, explorer, cooperator, hunter, cautious, wanderer.
Relative paths are relative to the current working directory.

8 ticks = one game second; 1440 ticks = three minutes. Headless runs do not
wait for wall-clock display pacing. Exported JSON contains the config, final
snapshot and accepted action history with inactive-agent IDs.

The runner's stdout is JSONL. In interactive mode, stdin accepts JSON objects
with command `pause`, `resume`, `step`, `stop`, or `export` (plus `path`). EOF
stops the session. Policy prints are drained separately; signals are the live
debugging surface. Round errors are shown on the native leaderboard.

Trust submitted code: it runs with your user permissions. Process separation,
bounded replies, common deadlines and process-group cleanup handle ordinary
programming errors; they are not an OS security sandbox.
