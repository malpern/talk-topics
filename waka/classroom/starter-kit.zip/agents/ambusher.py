"""Ambusher: cut off a prey's next turn, instead of always chasing its tail."""
from waka import emergency, me, vulnerable_players, destination, route, pickups, nearest, danger


def decide(observation, memory):
    escape = emergency(observation, radius=2)
    if escape is not None: return escape
    own = me(observation)
    if own['predator_ticks'] and not own['shield_ticks']:
        targets = [destination(observation, a['position'], a['direction']) for a in vulnerable_players(observation)]
        move, length = route(observation, targets, avoid=danger(observation))
        if length is not None and length+4 < own['predator_ticks']:
            return {'move': move, 'signal': 'Cutting off the next junction'}
    return nearest(observation, pickups(observation, 'predator') or observation['pellets'], avoid=danger(observation))
