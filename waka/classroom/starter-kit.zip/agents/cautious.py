"""Cautious: larger safety margin, power pellets before risky shortcuts."""
from waka import emergency, pickups, route, nearest, danger


def decide(observation, memory):
    escape = emergency(observation, radius=5)
    if escape is not None: return escape
    move, length = route(observation, pickups(observation, 'energizer'), avoid=danger(observation))
    if length is not None and length < 12: return move
    return nearest(observation, observation['pellets'], avoid=danger(observation))
