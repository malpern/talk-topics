"""Cautious: avoid ghost neighbourhoods; flee if one gets too close."""
from waka import MOVES, distance, me, nearest


def decide(observation, memory):
    ghosts = observation["ghosts"]
    position = me(observation)["position"]
    if ghosts and min(distance(position, g) for g in ghosts) <= 3:
        def safety(move):
            dx, dy = MOVES.get(move, (0, 0))
            return min(distance([position[0]+dx, position[1]+dy], g) for g in ghosts)
        return max(observation["legal_moves"], key=safety)
    avoid = [[g[0]+dx, g[1]+dy] for g in ghosts for dx, dy in [(0, 0), *MOVES.values()]]
    return nearest(observation, observation["pellets"], avoid=avoid)
