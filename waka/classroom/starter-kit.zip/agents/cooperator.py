"""Rescuer: collect energizers to make ghosts edible for everyone."""
from waka import emergency, nearest, pickups, hunt, danger


def decide(observation, memory):
    escape = emergency(observation, radius=2)
    if escape is not None: return escape
    if observation['frightened_ticks'] < 12 and pickups(observation, 'energizer'):
        return {'move': nearest(observation, pickups(observation, 'energizer'), avoid=danger(observation)),
                'signal': 'Going for power: blue ghosts help everyone'}
    chase = hunt(observation)
    return chase if chase is not None else nearest(observation, observation['pellets'], avoid=danger(observation))
