"""Cooperator: meet a partner on the two pads of a ready vault."""
from waka import distance, me, nearest


def decide(observation, memory):
    position = me(observation)["position"]
    others = [a for a in observation["agents"] if a["active"] and a["id"] != observation["you"]]
    ready = [v for v in observation["vaults"] if v["ready_at"] <= observation["tick"]]
    if ready and others:
        # Agree on a public rendezvous, then use IDs to choose different pads.
        # No access to another policy's code or private memory is needed.
        vault = min(ready, key=lambda v: v["id"])
        left, right = vault["pads"]
        invitation = f"Meet at vault {vault['id']+1}"
        partners = [a for a in others if a["signal"] == invitation]
        nearest_other = min(partners or others, key=lambda a: distance(a["position"], left))
        mine = (distance(position, left), observation["you"])
        theirs = (distance(nearest_other["position"], left), nearest_other["id"])
        pad = left if (observation["you"] < nearest_other["id"] if partners else mine < theirs) else right
        # Leave an unanswered invitation after 80 ticks, rather than camping
        # forever when no other cooperative agent is in the roster.
        if position == pad:
            memory["wait"] = memory.get("wait", 0)+1
        else:
            memory["wait"] = 0
        if memory.get("wait", 0) < 80:
            return {"move": nearest(observation, [pad]), "signal": invitation}
    return nearest(observation, observation["pellets"])
