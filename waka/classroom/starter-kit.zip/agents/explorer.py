"""Explorer: claim a distant quarter, then forage there. Remembers a goal."""
from waka import distance, me, nearest


def decide(observation, memory):
    corners = [[1, 1], [79, 1], [79, 53], [1, 53]]
    if "corner" not in memory:
        memory["corner"] = (observation["you"]+2) % 4
    goal = corners[memory["corner"]]
    pellets = [p for p in observation["pellets"] if distance(p, goal) < 24]
    if not pellets:
        memory["corner"] = (memory["corner"]+1) % 4
        return nearest(observation, observation["pellets"])
    return nearest(observation, pellets)
