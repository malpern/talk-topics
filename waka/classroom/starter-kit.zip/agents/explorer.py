"""Explorer: choose a distant quarter, then escape threats along the way."""
from waka import distance, emergency, nearest, danger


def decide(observation, memory):
    escape = emergency(observation)
    if escape is not None: return escape
    w, h = observation['width'], observation['height']
    corners = [[1,1], [w-2,1], [w-2,h-2], [1,h-2]]
    memory.setdefault('corner', (observation['you']+2) % 4)
    goals = [p for p in observation['pellets'] if distance(p, corners[memory['corner']]) < 12]
    if not goals:
        memory['corner'] = (memory['corner']+1) % 4
        goals = observation['pellets']
    return nearest(observation, goals, avoid=danger(observation))
