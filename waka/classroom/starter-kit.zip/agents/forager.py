"""Forager: dots first, except when a ghost or predator is close."""
from waka import emergency, nearest, danger


def decide(observation, memory):
    escape = emergency(observation)
    if escape is not None: return {'move': escape, 'signal': 'Keeping my dots, staying alive'}
    return nearest(observation, observation['pellets'], avoid=danger(observation))
