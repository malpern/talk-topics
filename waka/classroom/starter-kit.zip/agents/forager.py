"""Forager: take the shortest route to the nearest remaining pellet."""
from waka import nearest


def decide(observation, memory):
    return nearest(observation, observation["pellets"])
