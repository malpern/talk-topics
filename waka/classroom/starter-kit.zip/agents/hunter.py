"""Hunter: pursue a valuable leader when the bounty is available."""
from waka import nearest


def decide(observation, memory):
    leader = observation["leader"]
    if (leader is not None and leader != observation["you"]
            and observation["agents"][leader]["score"] >= 50
            and observation["tick"] >= observation["bounty_ready_at"]):
        return {"move": nearest(observation, [observation["agents"][leader]["position"]]),
                "signal": "Chasing the crown"}
    return nearest(observation, observation["pellets"])
