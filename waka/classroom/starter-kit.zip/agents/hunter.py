"""Hunter: seek predator power, then chase only reachable, unshielded prey."""
from waka import emergency, hunt, pickups, nearest, danger, me


def decide(observation, memory):
    escape = emergency(observation, radius=2)
    if escape is not None: return {'move': escape, 'signal': 'Predators still fear ghosts'}
    chase = hunt(observation)
    if chase is not None: return {'move': chase, 'signal': 'Hunting before my power expires'}
    targets = pickups(observation, 'predator') if me(observation)['predator_ticks'] < 8 else []
    return nearest(observation, targets or observation['pellets'], avoid=danger(observation))
