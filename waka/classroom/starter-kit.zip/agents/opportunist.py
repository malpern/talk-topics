"""Opportunist: compare points per travel tick, then switch when danger changes."""
from waka import emergency, hunt, route, pickups, danger


def decide(observation, memory):
    escape = emergency(observation)
    if escape is not None: return escape
    chase = hunt(observation)
    if chase is not None: return chase
    options = []
    for kind, value in [('fruit',100), ('energizer',50), ('predator',40), ('pellet',10)]:
        targets = observation['pellets'] if kind=='pellet' else pickups(observation, kind)
        move, length = route(observation, targets, avoid=danger(observation))
        if length is not None: options.append((value/(length+1), move, kind))
    if not options: return 'stay'
    _, move, kind = max(options)
    return {'move': move, 'signal': 'Best nearby opportunity: '+kind}
