"""Wanderer: visit memory and seeded choices, with an emergency escape rule."""
import random
from waka import emergency, me, destination


def decide(observation, memory):
    escape = emergency(observation)
    if escape is not None: return escape
    if 'random' not in memory:
        memory['random'] = random.Random(observation['seed']); memory['visits'] = {}
    position = tuple(me(observation)['position'])
    visits = memory['visits']; visits[position] = visits.get(position, 0)+1
    choices = [m for m in observation['legal_moves'] if m != 'stay']
    memory['random'].shuffle(choices)
    return min(choices, key=lambda m: visits.get(destination(observation, position, m), 0), default='stay')
