"""Wanderer: seeded randomness, preferring cells it has visited least."""
import random
from waka import MOVES, me


def decide(observation, memory):
    if "random" not in memory:
        memory["random"] = random.Random(observation["seed"])
        memory["visits"] = {}
    x, y = me(observation)["position"]
    visits = memory["visits"]
    visits[(x, y)] = visits.get((x, y), 0)+1
    choices = [m for m in observation["legal_moves"] if m != "stay"]
    memory["random"].shuffle(choices)
    return min(choices, key=lambda m: visits.get((x+MOVES[m][0], y+MOVES[m][1]), 0), default="stay")
