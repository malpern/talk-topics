"""Authored classroom rules, independent of Waka's arcade/replay core.

All numbers here are classroom design choices, not arcade constants.
Coordinates are [x, y], origin top left. Each step uses one shared snapshot.
"""
import copy
import random

WIDTH, HEIGHT = 81, 55
DIRECTIONS = {"up": (0, -1), "right": (1, 0), "down": (0, 1), "left": (-1, 0), "stay": (0, 0)}
COLORS = ["FFE34C", "65DBF3", "FF7599", "B9A0FF", "77E3AC", "FFB467",
          "EF9CFF", "A8D8FF", "D7EB71", "FF8A65", "86B9FF", "E7CCD6"]
STYLES = ["forager", "explorer", "cooperator", "hunter", "cautious", "wanderer"]
SPAWNS = [(1, 1), (27, 1), (53, 1), (79, 1), (79, 27), (79, 53),
          (53, 53), (27, 53), (1, 53), (1, 27), (27, 27), (53, 27)]


class Arena:
    def __init__(self, config):
        self.seed = int(config.get("seed", 42))
        self.random = random.Random(self.seed)
        self.limit = int(config.get("ticks", 1440))
        self.tick = 0
        self.rules = {key: bool(config.get(key, True)) for key in ("vaults", "portals", "bounty", "storms")}
        # Connected corridors: every odd row and column is open. Short wall
        # bars add room-like regions without severing those corridors.
        self.grid = ["".join("#" if x in (0, WIDTH-1) or y in (0, HEIGHT-1)
                            or (y % 4 == 0 and x % 8 in (2, 3, 4, 5, 6))
                            else "." for x in range(WIDTH)) for y in range(HEIGHT)]
        self.floor = [(x, y) for y in range(HEIGHT) for x in range(WIDTH) if self.grid[y][x] != "#"]
        self.pellets = set(self.floor) - set(SPAWNS)
        self.agents = []
        for index, entry in enumerate(config.get("agents", [{} for _ in range(12)])):
            self.agents.append(dict(id=index, name=str(entry.get("name", f"Agent {index+1}"))[:32],
                                    color=COLORS[index], position=list(SPAWNS[index]), score=0,
                                    signal="", status="ready", faults=0, detail="", active=True))
        self.vaults = [dict(id=i, pads=[[x-1, y], [x+1, y]], ready_at=0)
                       for i, (x, y) in enumerate([(20, 13), (60, 13), (20, 41), (60, 41)])] if self.rules["vaults"] else []
        self.portal_tiles = [[9, 9], [71, 9], [71, 45], [9, 45]] if self.rules["portals"] else []
        self.ghosts = []
        self.events = ["The classroom arena is ready."]
        self.bounty_ready = 0
        self.metrics = dict(pellets_collected=0, vault_openings=0, portal_trips=0, bounty_tags=0, storm_hits=0)

    def walkable(self, p):
        x, y = p
        return 0 <= x < WIDTH and 0 <= y < HEIGHT and self.grid[y][x] != "#"

    def leader(self):
        active = [a for a in self.agents if a["active"]]
        return min(active, key=lambda a: (-a["score"], a["id"]))["id"] if active else None

    def snapshot(self):
        shift = 1 + (self.tick // 80) % 3
        return copy.deepcopy(dict(version=1, tick=self.tick, ticks_left=max(0, self.limit-self.tick),
             width=WIDTH, height=HEIGHT, grid=self.grid, pellets=[list(p) for p in sorted(self.pellets)],
             agents=self.agents, rules=self.rules, vaults=self.vaults,
             portals=[dict(position=p, destination=self.portal_tiles[(i+shift) % 4])
                      for i, p in enumerate(self.portal_tiles)],
             portal_shift_in=80-self.tick % 80, ghosts=self.ghosts,
             storm_warning=self.rules["storms"] and 112 <= self.tick % 160 < 120,
             storm_in=120-self.tick % 160 if self.rules["storms"] and self.tick % 160 < 120 else None,
             leader=self.leader() if self.rules["bounty"] else None,
             bounty_ready_at=self.bounty_ready, metrics=self.metrics, events=self.events[-6:], done=self.tick >= self.limit))

    def observations(self):
        base = self.snapshot()
        return [dict(copy.deepcopy(base), you=a["id"], seed=self.seed + a["id"] * 1009,
                     legal_moves=[d for d, (dx, dy) in DIRECTIONS.items()
                                  if self.walkable((a["position"][0]+dx, a["position"][1]+dy))])
                for a in self.agents]

    def announce(self, message):
        self.events.append(message)
        self.events = self.events[-6:]

    def step(self, actions):
        if self.tick >= self.limit:
            return
        leader = self.leader()
        old_positions = {a["id"]: a["position"][:] for a in self.agents}
        shift = 1 + (self.tick // 80) % 3
        for a, action in zip(self.agents, actions):
            if not a["active"]:
                continue
            dx, dy = DIRECTIONS.get(action.get("move"), (0, 0))
            p = [a["position"][0]+dx, a["position"][1]+dy]
            if self.walkable(p):
                a["position"] = p
            # Portals trigger only on entry; standing still never loops.
            if p != old_positions[a["id"]] and a["position"] in self.portal_tiles:
                i = self.portal_tiles.index(a["position"])
                a["position"] = self.portal_tiles[(i+shift) % 4][:]
                self.metrics["portal_trips"] += 1
            a["signal"] = str(action.get("signal", ""))[:48]
        for p in sorted(self.pellets):
            eaters = [a for a in self.agents if a["active"] and tuple(a["position"]) == p]
            if eaters:
                # Split ten points; rotate remainder priority each tick.
                eaters.sort(key=lambda a: (a["id"]-self.tick) % len(self.agents))
                for i, a in enumerate(eaters):
                    a["score"] += 10 // len(eaters) + int(i < 10 % len(eaters))
                self.pellets.remove(p)
                self.metrics["pellets_collected"] += 1
        for vault in self.vaults:
            if self.tick < vault["ready_at"]:
                continue
            groups = [[a for a in self.agents if a["active"] and a["position"] == pad] for pad in vault["pads"]]
            if all(groups):
                # Reward one pair, rotating ties so a crowd cannot multiply rewards.
                pair = [min(group, key=lambda a: (a["id"]-self.tick) % len(self.agents)) for group in groups]
                for a in pair:
                    a["score"] += 100
                vault["ready_at"] = self.tick+80
                self.metrics["vault_openings"] += 1
                self.announce(f"{pair[0]['name']} + {pair[1]['name']} opened vault {vault['id']+1}: +100 each")
        if self.rules["bounty"] and leader is not None and self.tick >= self.bounty_ready:
            target = self.agents[leader]
            catchers = [a for a in self.agents if a["active"] and a["id"] != leader
                        and (a["position"] == target["position"] or
                             (a["position"] == old_positions[leader] and target["position"] == old_positions[a["id"]]))]
            if catchers and target["score"] >= 50:
                catcher = min(catchers, key=lambda a: (a["id"]-self.tick) % len(self.agents))
                target["score"] -= 50
                catcher["score"] += 50
                self.bounty_ready = self.tick+40
                self.metrics["bounty_tags"] += 1
                self.announce(f"{catcher['name']} tagged the leader: 50 points transferred")
        if self.rules["storms"]:
            phase = self.tick % 160
            if phase == 112:
                self.announce("Ghost storm in 8 ticks — keep your distance!")
            if phase == 120:
                self.ghosts = [[40, 1], [79, 27], [40, 53], [1, 27]]
                self.announce("Ghost storm! Ghosts move every other tick for 40 ticks.")
            if phase < 120:
                self.ghosts = []
            old_ghosts = copy.deepcopy(self.ghosts)
            if self.tick % 2 == 0:
                for i, ghost in enumerate(self.ghosts):
                    active = [a for a in self.agents if a["active"]]
                    if not active:
                        break
                    target = min(active, key=lambda a: abs(a["position"][0]-ghost[0])+abs(a["position"][1]-ghost[1]))["position"]
                    options = [[ghost[0]+dx, ghost[1]+dy] for d, (dx, dy) in DIRECTIONS.items() if d != "stay"]
                    self.ghosts[i] = min((p for p in options if self.walkable(p)),
                                        key=lambda p: abs(p[0]-target[0])+abs(p[1]-target[1]))
            for a in self.agents:
                hit = a["position"] in self.ghosts or any(
                    a["position"] == old and old_positions[a["id"]] == new
                    for old, new in zip(old_ghosts, self.ghosts))
                if a["active"] and hit:
                    a["score"] = max(0, a["score"]-30)
                    self.metrics["storm_hits"] += 1
                    # Prefer the spawn, but never respawn on a storm ghost.
                    spawn = SPAWNS[a["id"]]
                    a["position"] = list(next((p for p in [spawn]+self.floor if list(p) not in self.ghosts), spawn))
                    self.announce(f"{a['name']} caught in the storm: -30, respawned")
        self.tick += 1
        if self.tick % 80 == 0:
            # Replenish a seeded sample so late rounds still reward exploration.
            for p in self.random.sample(self.floor, min(100, len(self.floor))):
                self.pellets.add(p)
        if self.tick == self.limit:
            self.announce("Round complete. Equal scores share a place.")
