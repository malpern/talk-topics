"""Authored eight-player arcade classroom rules. No arcade-core/ROM dependency.

All timings and scores below are classroom design choices. One tick is 1/8 s.
"""
import copy
import random
from collections import deque
from maze import WIDTH, HEIGHT, TUNNEL_Y, SPAWNS, HOUSE, PORTAL_PAIRS, ENERGIZERS, PREDATORS, FRUIT, GRID

DIRECTIONS = {"up": (0, -1), "right": (1, 0), "down": (0, 1), "left": (-1, 0), "stay": (0, 0)}
COLORS = ["FFE34C", "65DBF3", "FF7599", "B9A0FF", "77E3AC", "FFB467", "EF9CFF", "A8D8FF"]
STYLES = ["forager", "explorer", "cooperator", "hunter", "cautious", "wanderer", "ambusher", "opportunist"]
GHOST_STYLES = ["chaser", "ambusher", "pincer", "shy", "guardian", "stalker", "roamer", "interceptor"]
GHOST_COLORS = ["FF424F", "FFB8DC", "54E4EC", "FFAD59", "B19AFF", "63E394", "ECA3FF", "CAD5FF"]
FRIGHT_TICKS, PREDATOR_TICKS, RESPAWN_TICKS, SHIELD_TICKS = 64, 48, 8, 24
GHOST_POINTS, PLAYER_POINTS, DEATH_COST = 200, 75, 50


class Arena:
    def __init__(self, config):
        self.seed = int(config.get("seed", 42))
        self.random = random.Random(self.seed)
        self.limit = int(config.get("ticks", 1440))
        self.tick, self.level = 0, 1
        entries = config.get("agents", [{} for _ in range(8)])
        if not 2 <= len(entries) <= 8:
            raise ValueError("Choose 2 to 8 players; each player adds one ghost")
        self.rules = {key: bool(config.get(key, True)) for key in ("portals", "power_pellets", "predator", "fruit")}
        self.grid = GRID[:]
        self.floor = [(x, y) for y in range(HEIGHT) for x in range(WIDTH) if self.grid[y][x] == '.']
        self.agents = [dict(id=i, name=str(entry.get("name", f"Agent {i+1}"))[:32], color=COLORS[i],
            position=list(SPAWNS[i]), direction="left", score=0, signal="", status="ready", faults=0,
            detail="", active=True, respawn_at=0, shield_until=16, predator_until=0, deaths=0, captures=0)
            for i, entry in enumerate(entries)]
        self.ghosts = [dict(id=i, name=GHOST_STYLES[i].capitalize(), style=GHOST_STYLES[i],
            color=GHOST_COLORS[i], position=list(HOUSE[i]), direction="up", state="house", release_at=16+i*4)
            for i in range(len(entries))]
        self.portals = []
        if self.rules['portals']:
            for a, b in PORTAL_PAIRS:
                self.portals.extend([dict(position=list(a), destination=list(b)), dict(position=list(b), destination=list(a))])
        self.portal_map = {tuple(p['position']): tuple(p['destination']) for p in self.portals}
        self.powerups = []
        for kind, positions, rule in [('energizer', ENERGIZERS, 'power_pellets'), ('predator', PREDATORS, 'predator'), ('fruit', FRUIT, 'fruit')]:
            if self.rules[rule]:
                for p in positions:
                    self.powerups.append(dict(id=len(self.powerups), kind=kind, position=list(p), ready_at=0))
        self.pellet_floor = set(self.floor)-{tuple(p['position']) for p in self.powerups}-set(SPAWNS)
        self.pellets = set(self.pellet_floor)
        self.fright_until = 0
        self.events = ["READY! Eight minds. Eight ghosts."]
        self.sounds = []
        self.metrics = dict(pellets_collected=0, portal_trips=0, energizers=0, predators=0, fruit=0,
                            ghosts_eaten=0, players_eaten=0, ghost_deaths=0, boards_cleared=0)
        # Ghosts can enter the house and side tunnel, but never player teleports.
        self.ghost_graph = {p: self.neighbours(p, ghost=True) for p in
                            [(x,y) for y in range(HEIGHT) for x in range(WIDTH) if self.walkable((x,y), True)]}

    def walkable(self, p, ghost=False):
        x, y = p
        return 0 <= x < WIDTH and 0 <= y < HEIGHT and self.grid[y][x] in ('.h=' if ghost else '.')

    def destination(self, p, move, ghost=False):
        dx, dy = DIRECTIONS.get(move, (0, 0))
        q = (p[0]+dx, p[1]+dy)
        if q[1] == TUNNEL_Y: q = (q[0] % WIDTH, q[1])
        if not self.walkable(q, ghost): return tuple(p)
        return self.portal_map.get(q, q) if not ghost and q != tuple(p) else q

    def neighbours(self, p, ghost=False):
        return [(d, self.destination(p, d, ghost)) for d in DIRECTIONS if d != 'stay'
                and self.destination(p, d, ghost) != tuple(p)]

    def alive(self, a): return a['active'] and a['respawn_at'] <= self.tick
    def protected(self, a): return a['shield_until'] > self.tick
    def predator(self, a): return a['predator_until'] > self.tick and self.alive(a) and not self.protected(a)

    def snapshot(self):
        agents = [dict(a, alive=self.alive(a), predator_ticks=max(0, a['predator_until']-self.tick),
                       shield_ticks=max(0, a['shield_until']-self.tick), respawn_ticks=max(0, a['respawn_at']-self.tick)) for a in self.agents]
        ghosts = [dict(g, state=('frightened' if self.tick < self.fright_until else 'chase') if g['state']=='roaming' else g['state']) for g in self.ghosts]
        return copy.deepcopy(dict(version=2, tick=self.tick, ticks_left=max(0, self.limit-self.tick), level=self.level,
            width=WIDTH, height=HEIGHT, grid=self.grid, pellets=[list(p) for p in sorted(self.pellets)],
            agents=agents, ghosts=ghosts, portals=self.portals, powerups=[dict(p, available=p['ready_at'] <= self.tick) for p in self.powerups],
            tunnel_y=TUNNEL_Y, rules=self.rules, frightened_ticks=max(0, self.fright_until-self.tick),
            events=self.events[-5:], sounds=self.sounds, metrics=self.metrics, done=self.tick >= self.limit))

    def observations(self):
        base = self.snapshot()
        return [dict(copy.deepcopy(base), you=a['id'], seed=self.seed+a['id']*1009,
                     legal_moves=['stay']+[d for d, _ in self.neighbours(a['position'])] if self.alive(a) else ['stay']) for a in self.agents]

    def announce(self, text, sound=None):
        self.events = (self.events+[text])[-5:]
        if sound: self.sounds.append(sound)

    def respawn(self, a):
        a['position'] = list(SPAWNS[a['id']])
        a['respawn_at'] = self.tick+RESPAWN_TICKS
        a['shield_until'] = a['respawn_at']+SHIELD_TICKS
        a['predator_until'] = 0
        a['deaths'] += 1

    def ghost_distances(self, target):
        target = min(self.ghost_graph, key=lambda p: abs(p[0]-target[0])+abs(p[1]-target[1]))
        result, queue = {target: 0}, deque([target])
        while queue:
            p = queue.popleft()
            for _, q in self.ghost_graph[p]:
                if q not in result: result[q] = result[p]+1; queue.append(q)
        return result

    def move_ghosts(self):
        live = [a for a in self.agents if self.alive(a)]
        corners = [(1,1), (39,1), (39,35), (1,35)]
        for g in self.ghosts:
            p = tuple(g['position'])
            if g['state'] == 'house':
                if self.tick < g['release_at']: continue
                target = (20,13)
                if p == target: g['state'] = 'roaming'
            if g['state'] == 'eyes':
                target = HOUSE[g['id']]
                if p == target:
                    g['state'] = 'house'; g['release_at'] = self.tick+16; continue
            elif g['state'] == 'roaming':
                if not live: continue
                fright = self.tick < self.fright_until
                if (fright and self.tick % 2) or (not fright and self.tick % 4 == 3): continue
                closest = min(live, key=lambda a: abs(a['position'][0]-p[0])+abs(a['position'][1]-p[1]))
                target = tuple(closest['position'])
                direction = DIRECTIONS.get(closest['direction'], (0,0))
                style = g['style']
                if style == 'ambusher': target = (target[0]+4*direction[0], target[1]+4*direction[1])
                elif style == 'pincer': target = tuple(live[(g['id']+self.tick//32) % len(live)]['position'])
                elif style == 'shy' and abs(target[0]-p[0])+abs(target[1]-p[1]) < 7: target = corners[g['id'] % 4]
                elif style == 'guardian': target = ENERGIZERS[(self.tick//64) % 4]
                elif style == 'stalker': target = tuple(max(live, key=lambda a: a['score'])['position'])
                elif style == 'roamer': target = corners[(self.tick//48+self.seed) % 4]
                elif style == 'interceptor':
                    predators = [a for a in live if self.predator(a)]
                    if predators: target = tuple(min(predators, key=lambda a: abs(a['position'][0]-p[0])+abs(a['position'][1]-p[1]))['position'])
                if fright: target = tuple(closest['position'])
                # Authored scatter intervals let the maze breathe, as in an arcade.
                if not fright and self.tick % 160 < 32: target = corners[g['id'] % 4]
            options = self.ghost_graph[p]
            if not options: continue
            distances = self.ghost_distances(target)
            reverse = {'up':'down', 'down':'up', 'left':'right', 'right':'left'}[g['direction']]
            if g['state'] == 'roaming':
                floor_options = [(d,q) for d,q in options if self.grid[q[1]][q[0]] == '.']
                options = [(d,q) for d,q in floor_options if d != reverse] or floor_options
            frightened = g['state'] == 'roaming' and self.tick < self.fright_until
            choose = max if frightened else min
            direction, q = choose(options, key=lambda item: distances.get(item[1], 10000))
            g['position'], g['direction'] = list(q), direction
            if g['state']=='house' and q == (20,13): g['state'] = 'roaming'

    @staticmethod
    def contact(a, b, old_a, old_b):
        return a == b or (a == old_b and b == old_a)

    def collect_pickups(self):
        for p in sorted(self.pellets):
            eaters = [a for a in self.agents if self.alive(a) and tuple(a['position']) == p]
            if eaters:
                eaters.sort(key=lambda a: (a['id']-self.tick) % len(self.agents))
                for i,a in enumerate(eaters): a['score'] += 10//len(eaters)+int(i < 10 % len(eaters))
                self.pellets.remove(p); self.metrics['pellets_collected'] += 1
                self.sounds.append('chomp')
        # A contested power-up has one owner, chosen by rotating priority. It is
        # consumed before combat, so an energizer can save you on the same tick.
        for power in self.powerups:
            eaters = [a for a in self.agents if self.alive(a) and a['position'] == power['position']]
            if self.tick < power['ready_at'] or not eaters: continue
            a = min(eaters, key=lambda a: (a['id']-self.tick) % len(self.agents))
            kind = power['kind']
            power['ready_at'] = self.tick+(192 if kind=='predator' else 320 if kind=='energizer' else 96)
            if kind == 'energizer':
                self.fright_until = self.tick+FRIGHT_TICKS; a['score'] += 50; self.metrics['energizers'] += 1
                self.announce(f"{a['name']}: POWER PELLET! Blue ghosts are edible for everyone.", 'power')
            elif kind == 'predator':
                a['predator_until'] = self.tick+PREDATOR_TICKS; self.metrics['predators'] += 1
                self.announce(f"{a['name']} is a PREDATOR for 6 seconds — watch the red ring!", 'predator')
            else:
                a['score'] += 100; self.metrics['fruit'] += 1
                self.announce(f"{a['name']} collected cherries: +100", 'fruit')

    def combat(self, old, old_ghost):
        # Ghost combat resolves first. A predator caught by a ghost cannot also
        # eat a player during the same tick. Eyes and house ghosts never harm.
        for g in self.ghosts:
            if g['state'] != 'roaming': continue
            touches = [a for a in self.agents if self.alive(a) and self.contact(a['position'], g['position'], old[a['id']], old_ghost[g['id']])]
            if self.tick < self.fright_until and touches:
                a = min(touches, key=lambda a: (a['id']-self.tick) % len(self.agents))
                a['score'] += GHOST_POINTS; a['captures'] += 1
                g['state'] = 'eyes'; self.metrics['ghosts_eaten'] += 1
                self.announce(f"{a['name']} ate {g['name']}: +200", 'ghost')
            else:
                for a in touches:
                    if self.protected(a): continue
                    a['score'] = max(0, a['score']-DEATH_COST); self.metrics['ghost_deaths'] += 1
                    self.respawn(a); self.announce(f"{g['name']} caught {a['name']}: -50", 'death')
        captures = []
        for prey in self.agents:
            if not self.alive(prey) or self.protected(prey) or self.predator(prey): continue
            hunters = [a for a in self.agents if a['id'] != prey['id'] and self.predator(a)
                       and self.contact(a['position'], prey['position'], old[a['id']], old[prey['id']])]
            if hunters: captures.append((min(hunters, key=lambda a: (a['id']-self.tick) % len(self.agents)), prey))
        for hunter, prey in captures:
            points = min(PLAYER_POINTS, prey['score'])
            hunter['score'] += points; prey['score'] -= points; hunter['captures'] += 1
            self.metrics['players_eaten'] += 1; self.respawn(prey)
            self.announce(f"{hunter['name']} ate {prey['name']}: {points} points stolen", 'eat_player')

    def move_player(self, a, move):
        p = self.destination(a['position'], move)
        if p != tuple(a['position']):
            if abs(p[0]-a['position'][0])+abs(p[1]-a['position'][1]) > 1:
                self.metrics['portal_trips'] += 1; self.sounds.append('teleport')
            a['direction'] = move
            a['position'] = list(p)

    def step(self, actions):
        if self.tick >= self.limit: return
        self.sounds = []
        if self.tick == 0: self.sounds.append('start')
        boosted = {a['id'] for a in self.agents if self.predator(a)} if self.tick % 2 == 0 else set()
        old = {a['id']: a['position'][:] for a in self.agents}
        old_ghost = {g['id']: g['position'][:] for g in self.ghosts}
        for a, action in zip(self.agents, actions):
            if not self.alive(a): continue
            self.move_player(a, action.get('move', 'stay'))
            a['signal'] = str(action.get('signal', ''))[:48]
        self.collect_pickups()
        self.move_ghosts()
        self.combat(old, old_ghost)
        # Predators get an extra straight-corridor step on even ticks. Stop at
        # junctions, so a speed bonus never forces an agent past its next turn.
        # Pickups and collisions resolve on BOTH substeps; no tunnelling through
        # a ghost or prey while moving two tiles in a tick.
        if boosted:
            old = {a['id']: a['position'][:] for a in self.agents}
            old_ghost = {g['id']: g['position'][:] for g in self.ghosts}
            reverse = {'up':'down', 'down':'up', 'left':'right', 'right':'left', 'stay':'stay'}
            for a, action in zip(self.agents, actions):
                move = action.get('move', 'stay')
                if a['id'] not in boosted or not self.predator(a) or move == 'stay': continue
                forward = [d for d,_ in self.neighbours(a['position']) if d != reverse[move]]
                if forward == [move]: self.move_player(a, move)
            self.collect_pickups()
            self.combat(old, old_ghost)
        if not self.pellets:
            self.level += 1; self.metrics['boards_cleared'] += 1
            self.pellets = set(self.pellet_floor)
            self.announce('MAZE CLEARED! Fresh dots for the next board.', 'clear')
        self.sounds = list(dict.fromkeys(self.sounds))
        self.tick += 1
        if self.tick == self.limit: self.announce('ROUND OVER — tied scores share a place.', 'finish')
