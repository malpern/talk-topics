"""Authored maze inspired by arcade maze grammar, not a ROM tile extraction.

Mirrored wall islands, a central ghost pen, loops and two side tunnel mouths.
The 41 x 37 layout replaces the classroom's open striped field.
"""
WIDTH, HEIGHT = 41, 37
TUNNEL_Y = 17
SPAWNS = [(1, 1), (39, 1), (39, 35), (1, 35), (7, 13), (33, 13), (27, 25), (13, 25)]
HOUSE = [(17+i % 7, 16+i//7) for i in range(8)]
PORTAL_PAIRS = [((7, 9), (33, 29)), ((33, 9), (7, 29))]
ENERGIZERS = [(1, 5), (39, 5), (1, 29), (39, 29)]
PREDATORS = [(13, 9), (27, 9)]
FRUIT = [(20, 21)]


def make_grid():
    cells = [['#']*WIDTH for _ in range(HEIGHT)]
    def horizontal(y, left, right):
        for x in range(left, right+1): cells[y][x] = '.'
    def vertical(x, top, bottom):
        for y in range(top, bottom+1): cells[y][x] = '.'
    for y in (1, 5, 25, 35): horizontal(y, 1, 39)
    cells[1][20] = '#'
    for y in (9, 13, 21): horizontal(y, 7, 33)
    for left, right in ((1, 13), (27, 39)): horizontal(9, left, right)
    for left, right in ((0, 15), (25, 40)): horizontal(17, left, right)
    for left, right in ((1, 7), (13, 27), (33, 39)): horizontal(29, left, right)
    for left, right in ((7, 13), (27, 33)): horizontal(33, left, right)
    for x in (1, 39):
        vertical(x, 1, 9); vertical(x, 25, 35)
    for x in (7, 33): vertical(x, 1, 35)
    for x in (13, 27):
        vertical(x, 1, 5); vertical(x, 9, 29); vertical(x, 33, 35)
    for x in (19, 21):
        vertical(x, 1, 9); vertical(x, 25, 35)
    for x in (15, 25): vertical(x, 13, 21)
    vertical(20, 13, 15)
    # A T-shaped central wall divides the upper and lower approaches.
    for x in range(17, 24): cells[9][x] = '#'
    horizontal(7, 13, 27)
    vertical(13, 5, 9); vertical(27, 5, 9)
    # Ghost-only floor and gate: players route around the pen.
    for y in range(16, 19):
        for x in range(17, 24): cells[y][x] = 'h'
    cells[15][20] = '='
    return [''.join(row) for row in cells]


GRID = make_grid()
