"""Local classroom host: JSONL frames on stdout, commands on stdin.

Student code runs as the current user, not in a security sandbox. Each worker
has an independent process; a common deadline prevents one bot freezing play.
"""
import argparse
import collections
import json
import os
from pathlib import Path
import queue
import selectors
import signal
import subprocess
import sys
import threading
import time

from arena import Arena, DIRECTIONS, STYLES

ROOT = Path(__file__).resolve().parent
MAX_REPLY = 4096


class Worker:
    def __init__(self, path):
        self.process = subprocess.Popen([sys.executable, '-u', str(ROOT/'worker.py'), str(path)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
        os.set_blocking(self.process.stdout.fileno(), False)
        os.set_blocking(self.process.stdin.fileno(), False)
        self.buffer = b''
        self.outgoing = b''
        self.logs = collections.deque(maxlen=3)
        self.closed = False
        def drain():
            # Bounded chunks, including programs that print without a newline.
            while True:
                chunk = self.process.stderr.read(512)
                if not chunk:
                    break
                self.logs.append(chunk.decode('utf-8', errors='replace')[-240:])
        self.log_thread = threading.Thread(target=drain, daemon=True)
        self.log_thread.start()

    def send(self, value):
        self.outgoing = (json.dumps(value, separators=(',', ':'))+'\n').encode()

    def close(self):
        if self.closed:
            return
        self.closed = True
        # Kill the worker's process group too, so ordinary child processes do
        # not survive a stopped round. This is cleanup, not hostile-code isolation.
        try:
            os.killpg(self.process.pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            if self.process.poll() is None:
                self.process.kill()
        self.process.wait(timeout=2)
        self.process.stdin.close()
        self.process.stdout.close()
        self.log_thread.join(timeout=1)
        self.process.stderr.close()


class Classroom:
    def __init__(self, config):
        entries = config.get('agents', [])
        if not 2 <= len(entries) <= 12:
            raise ValueError('Choose 2 to 12 agents')
        if not 1 <= int(config.get('ticks', 1440)) <= 4800:
            raise ValueError('Round length must be 1 to 4800 ticks')
        self.arena = Arena(config)
        self.workers = []
        self.budget = max(0.02, min(0.5, float(config.get('budget_ms', 100))/1000))
        self.history = []
        self.config = config
        try:
            for entry in entries:
                style = entry.get('style', 'forager')
                path = Path(entry['path']).expanduser().resolve() if entry.get('path') else ROOT/'agents'/f'{style}.py'
                if not entry.get('path') and style not in STYLES:
                    raise ValueError('Unknown built-in style')
                if path.suffix != '.py' or not path.is_file():
                    raise ValueError(f'Agent file not found: {path}')
                self.workers.append(Worker(path))
            # Startup imports get their own generous common deadline.
            replies = self.collect(set(range(len(entries))), time.monotonic()+5)
            for i, reply in replies.items():
                if reply != {'ready': True}:
                    self.fail(i, 'Startup failed: '+str(reply), fatal=True)
        except BaseException:
            self.close()
            raise

    def fail(self, i, reason, fatal=False):
        a = self.arena.agents[i]
        a['faults'] += 1
        a['detail'] = str(reason)[:240]
        a['status'] = 'stayed: '+str(reason)[:90]
        if fatal or a['faults'] >= 3:
            a['active'] = False
            a['status'] = 'stopped'
            self.workers[i].close()
            self.arena.announce(f"{a['name']} stopped: {a['detail']}")

    def collect(self, pending, deadline):
        result = {}
        with selectors.DefaultSelector() as selector:
            for i in pending:
                selector.register(self.workers[i].process.stdout, selectors.EVENT_READ, i)
                if self.workers[i].outgoing:
                    selector.register(self.workers[i].process.stdin, selectors.EVENT_WRITE, i)
            while selector.get_map() and time.monotonic() < deadline:
                for key, _ in selector.select(max(0, deadline-time.monotonic())):
                    i = key.data
                    worker = self.workers[i]
                    if key.events == selectors.EVENT_WRITE:
                        try:
                            written = os.write(key.fd, worker.outgoing[:4096])
                            worker.outgoing = worker.outgoing[written:]
                        except BrokenPipeError:
                            worker.outgoing = b''
                        if not worker.outgoing:
                            selector.unregister(key.fd)
                        continue
                    chunk = os.read(key.fd, MAX_REPLY+1)
                    worker.buffer += chunk
                    if len(worker.buffer) > MAX_REPLY:
                        result[i] = {'error': 'Reply exceeds 4096 bytes'}
                    elif b'\n' in worker.buffer:
                        line, worker.buffer = worker.buffer.split(b'\n', 1)
                        try:
                            result[i] = json.loads(line)
                        except (ValueError, UnicodeError):
                            result[i] = {'error': 'Reply is not valid JSON'}
                    elif not chunk:
                        result[i] = {'error': 'Process exited. '+''.join(worker.logs)[-180:]}
                    else:
                        continue
                    selector.unregister(key.fd)
                    # A reply before the request has been consumed is invalid.
                    if worker.outgoing:
                        result[i] = {'error': 'Reply before full observation', 'timeout': True}
                        try:
                            selector.unregister(worker.process.stdin)
                        except KeyError:
                            pass
        for i in pending-result.keys():
            result[i] = {'error': 'Decision deadline exceeded', 'timeout': True}
        return result

    def step(self):
        actions = [{'move': 'stay'} for _ in self.workers]
        observations = self.arena.observations()
        pending = set()
        # Workers have consumed their previous request before this send. JSON
        # input is bounded by the fixed arena and roster size.
        for i, worker in enumerate(self.workers):
            if not self.arena.agents[i]['active']:
                continue
            try:
                worker.send(observations[i])
                pending.add(i)
            except (OSError, ValueError) as error:
                self.fail(i, f'Process exited: {error}', fatal=True)
        replies = self.collect(pending, time.monotonic()+self.budget)
        for i, reply in replies.items():
            if not isinstance(reply, dict):
                self.fail(i, 'Return a direction or a dictionary')
            elif reply.get('error'):
                self.fail(i, reply['error'], fatal=bool(reply.get('timeout')))
            elif reply.get('tick') != self.arena.tick:
                self.fail(i, 'Wrong tick in reply', fatal=True)
            elif not isinstance(reply.get('move'), str) or reply['move'] not in DIRECTIONS:
                self.fail(i, 'Unknown move; use up, right, down, left or stay')
            elif not isinstance(reply.get('signal', ''), str) or len(reply.get('signal', '')) > 48:
                self.fail(i, 'Signal must be text, at most 48 characters')
            else:
                actions[i] = reply
                self.arena.agents[i]['status'] = 'playing'
        self.arena.step(actions)
        # Record accepted actions, seed and settings for an inspectable result.
        self.history.append({'tick': self.arena.tick-1, 'actions': actions,
                             'inactive': [a['id'] for a in self.arena.agents if not a['active']]})
        return self.arena.snapshot()

    def close(self):
        for worker in self.workers:
            worker.close()

    def export(self, path):
        Path(path).write_text(json.dumps({'version': 1, 'config': self.config,
            'result': self.arena.snapshot(), 'history': self.history}, indent=2))


def main():
    # A native window close must reap student processes even during a wait.
    def terminate(_signum, _frame):
        raise SystemExit(0)
    signal.signal(signal.SIGTERM, terminate)
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True, type=Path)
    parser.add_argument('--headless', action='store_true')
    parser.add_argument('--result', type=Path)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    classroom = None
    commands = queue.Queue()
    def read_commands():
        for line in sys.stdin:
            try:
                commands.put(json.loads(line))
            except ValueError:
                pass
        commands.put({'command': 'stop'})
    def emit(frame):
        print(json.dumps(frame, separators=(',', ':')), flush=True)
    try:
        classroom = Classroom(config)
        if not args.headless:
            threading.Thread(target=read_commands, daemon=True).start()
            emit(classroom.arena.snapshot())
        paused = False
        while classroom.arena.tick < classroom.arena.limit:
            start = time.monotonic()
            step_once = False
            stop = False
            while not commands.empty():
                command = commands.get()
                action = command.get('command')
                if action == 'stop': stop = True
                elif action == 'pause': paused = True
                elif action == 'resume': paused = False
                elif action == 'step': paused = True; step_once = True
                elif action == 'export': classroom.export(command['path'])
            if stop:
                break
            if not paused or step_once:
                frame = classroom.step()
                if not args.headless:
                    emit(frame)
            if not args.headless:
                time.sleep(max(0, 0.125-(time.monotonic()-start)))
        if args.result:
            classroom.export(args.result)
        if args.headless:
            emit(classroom.arena.snapshot())
    except Exception as error:
        emit({'error': f'{type(error).__name__}: {error}'})
        return 1
    finally:
        if classroom:
            classroom.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
