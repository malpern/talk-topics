"""Original procedural arcade cues; no sampled or ROM-derived sound assets.

Run with an output folder to build 44.1 kHz mono PCM WAVs for the Mac player.
"""
import math
from pathlib import Path
import struct
import sys
import wave

RATE = 44100


def tone(start, end, duration, volume=0.28, square=False):
    count = int(RATE*duration)
    phase = 0.0
    values = []
    for i in range(count):
        t = i/max(1,count-1)
        frequency = start+(end-start)*t
        phase += 2*math.pi*frequency/RATE
        envelope = min(1, i/(RATE*0.004))*min(1, (count-i)/(RATE*0.012))
        value = math.sin(phase)
        if square: value = 0.72*value+0.20*math.sin(phase*3)+0.08*math.sin(phase*5)
        values.append(int(32767*volume*envelope*value))
    return values


def notes(frequencies, length=0.085):
    return [sample for frequency in frequencies for sample in tone(frequency,frequency,length,square=True)]


def build(folder):
    folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
    cues = {
        'chomp': tone(820,270,0.07,0.13,True),
        'chomp2': tone(330,880,0.07,0.13,True),
        'start': notes([523,784,659,1047,784,1319],0.11),
        'power': notes([330,440,659,880,1319]),
        'predator': notes([196,233,294,392,587],0.11),
        'ghost': tone(450,1650,0.20,0.25,True),
        'eat_player': notes([880,659,440,220],0.06)+tone(180,65,0.14,0.30,True),
        'death': tone(740,80,0.45,0.22,True),
        'teleport': tone(260,1600,0.10,0.16)+tone(1600,460,0.10,0.16),
        'fruit': notes([784,1047,1319],0.065),
        'clear': notes([523,659,784,1047,1319,1568],0.09),
        'finish': notes([784,659,523,392,523],0.12),
        'siren': tone(170,235,0.5,0.08)+tone(235,170,0.5,0.08),
        'frightened': notes([220,330,220,294],0.16),
    }
    for name, samples in cues.items():
        with wave.open(str(folder/(name+'.wav')), 'wb') as output:
            output.setnchannels(1); output.setsampwidth(2); output.setframerate(RATE)
            output.writeframes(struct.pack('<'+'h'*len(samples), *samples))
    return cues


if __name__ == '__main__': build(sys.argv[1])
