"""One student's policy process. The host owns timing, scoring and validation."""
import contextlib
import importlib.util
import json
import sys
from pathlib import Path


def main():
    protocol = sys.stdout
    sys.path.insert(0, str(Path(sys.argv[1]).resolve().parent))
    # Student prints are debug output, never protocol messages.
    with contextlib.redirect_stdout(sys.stderr):
        spec = importlib.util.spec_from_file_location("student_agent", sys.argv[1])
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if not callable(getattr(module, "decide", None)):
            raise ValueError("Your file needs def decide(observation, memory)")
    memory = {}
    protocol.write('{"ready":true}\n')
    protocol.flush()
    for line in sys.stdin:
        observation = json.loads(line)
        try:
            with contextlib.redirect_stdout(sys.stderr):
                answer = module.decide(observation, memory)
            if isinstance(answer, str):
                answer = {"move": answer}
            if not isinstance(answer, dict):
                raise ValueError("Return a direction string or {'move': direction}")
            answer = {"tick": observation["tick"], "move": answer.get("move", "stay"),
                      "signal": answer.get("signal", "")}
        except Exception as error:
            answer = {"tick": observation["tick"], "error": f"{type(error).__name__}: {error}"[:240]}
        protocol.write(json.dumps(answer) + "\n")
        protocol.flush()


if __name__ == "__main__":
    main()
